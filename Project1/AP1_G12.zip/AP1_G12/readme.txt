To impute values for given testing data given naidx 
#Command to run - python3 knn_test.py

To impute values for given training data and calculates RMSD
#Command to run - python3 knn_train.py

Replace filenames for groundtruth, testing data and naidx
